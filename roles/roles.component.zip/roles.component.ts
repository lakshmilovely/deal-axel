import { Component, OnInit } from '@angular/core';
import { RolesService } from '../core/roles.service';
@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.scss']
})
export class RolesComponent implements OnInit {
  roledata: any;
  public role=''
  public type=''
  public status=''
  rid: any;
  date=new Date()
  save:boolean=false;
  add12:boolean=false;
  datatoedit: any;
  constructor(public rty:RolesService) { }

  ngOnInit(): void {

    this.rty.view().subscribe((data)=>{
      console.log(data);
      this.roledata=data
    })
    
  }
  adduser(){
    this.add12=true;
    this.save=false;
    this.role=''
    this.type=''
    this.status=''
   }
  
  saveroles(){
    const obj=
              {
                "rId": 0,
                "rName": this.role,
                "rType": this.type,
                "rStatus": this.status,
                "rTs": this.date
              }
          console.log(obj)
    this.rty.save(obj).subscribe((data)=>{
      alert("Roles Added Succesfully")
      console.log(data);
     
    })
     this.ngOnInit();
  }
  edit(data:any) {
    this.add12=false;
this.save=true;
    console.log(data);
 
  this.rid=data.rId,
  this.role=data.rName,
  this.type=data.rType,
  this.status=data.rStatus
  // })
  this.datatoedit=data
   
  }
  editsave(id:any){
    // this.id=this.act.snapshot.params['data'];
    // console.log(this.id)
    console.log(id)
      const obj=
      {
        "rId": id,
        "rName": this.role,
        "rType": this.type,
        "rStatus": this.status,
        "rTs": this.date
      }
    
    console.log(obj)
    this.rty.editrole(obj).subscribe((data12)=>{
    alert(" Roles updated Succesfully")
    console.log(data12);
    
    })
    this.ngOnInit();
    }
// remove(id:any){
//   console.log(id);
    
//   const obj={
//     "rId": id,
//     "rName": "string",
//     "rType": "string",
//     "rStatus": "D",
//     "rTs": "2022-08-09T11:31:44.933Z"

//   }
//   console.log(obj)
//   this.rty.editrole(obj).subscribe((data12)=>{
//   alert("Deleted Succesfully")
//   console.log(data12);
  
//   })
//   this.ngOnInit();
// }

}
